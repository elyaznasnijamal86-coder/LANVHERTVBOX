package com.example.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {

    // ---------- واجهات ----------
    private lateinit var tilesRow: LinearLayout
    private lateinit var homeLayer: View
    private lateinit var grid: GridView
    private lateinit var quranLayer: LinearLayout
    private lateinit var web: WebView
    private lateinit var hint: TextView
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    private val defaults = listOf(
        "com.google.android.youtube.tv",
        "com.netflix.ninja",
        "com.amazon.amazonvideo.livingroom",
        "com.android.vending"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(fill: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat(); setColor(fill); setStroke(dp(3), stroke)
    }
    private fun tileBg() = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), shape(0x66FFFFFF, Color.WHITE))
        addState(intArrayOf(), shape(0x33FFFFFF, 0x00000000))
    }
    private fun scaleOnFocus(v: View) {
        v.setOnFocusChangeListener { x, f ->
            val s = if (f) 1.08f else 1f
            x.animate().scaleX(s).scaleY(s).setDuration(150).start()
        }
    }

    // ---------- مواقيت الصلاة ----------
    private val prayerNames = linkedMapOf(
        "Fajr" to "الفجر", "Sunrise" to "الشروق", "Dhuhr" to "الظهر",
        "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء"
    )
    private var timings: Map<String, String> = emptyMap()
    private lateinit var prayerBar: LinearLayout
    private lateinit var nextText: TextView
    private val prayerCells = HashMap<String, TextView>()
    private var lastAdhan = ""
    private var adhanPlayer: MediaPlayer? = null
    private val ticker = object : Runnable {
        override fun run() { updatePrayerUi(); handler.postDelayed(this, 1000) }
    }

    // ---------- القرآن ----------
    data class Rec(val name: String, val server: String, val surahs: List<Int>)
    private var recs = listOf<Rec>()
    private var suwar = mapOf<Int, String>()
    private var qLevel = 0
    private var curRec: Rec? = null
    private var curIndex = 0
    private var player: MediaPlayer? = null
    private lateinit var qTitle: TextView
    private lateinit var qList: ListView
    private lateinit var qStatus: TextView
    private var qItems = listOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0B1E5B.toInt(), 0xFF2A0F6B.toInt(), 0xFF0A3D91.toInt())
            )
        }

        // ===== الرئيسية =====
        val home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(28), dp(48), dp(28))
        }
        val time = TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 48f; setTextColor(Color.WHITE)
        }
        val date = TextClock(this).apply {
            format24Hour = "EEEE, d MMMM yyyy"; format12Hour = "EEEE, d MMMM yyyy"
            textSize = 18f; setTextColor(0xFFB8D4FF.toInt())
        }
        buildPrayerBar()
        tilesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false; clipToPadding = false
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false; clipToPadding = false
            addView(tilesRow)
        }
        hint = TextView(this).apply { textSize = 13f; setTextColor(0xFFB8D4FF.toInt()) }
        home.addView(time); home.addView(date)
        home.addView(prayerBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })
        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        home.addView(hint); home.addView(scroller)
        homeLayer = home

        // ===== كل التطبيقات =====
        grid = GridView(this).apply {
            numColumns = 6
            verticalSpacing = dp(16); horizontalSpacing = dp(16)
            setPadding(dp(48), dp(36), dp(48), dp(36)); clipToPadding = false
            selector = shape(0x55FFFFFF, Color.WHITE)
            visibility = View.GONE
            setOnItemClickListener { _, _, pos, _ ->
                launch((adapter as AppsAdapter).apps[pos].activityInfo.packageName)
            }
        }

        // ===== القرآن =====
        quranLayer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(32), dp(48), dp(24)); visibility = View.GONE
        }
        qTitle = TextView(this).apply { textSize = 28f; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(12)) }
        qList = ListView(this).apply {
            selector = shape(0x55FFFFFF, Color.WHITE); divider = null
            setOnItemClickListener { _, _, pos, _ -> onQuranClick(pos) }
        }
        qStatus = TextView(this).apply { textSize = 16f; setTextColor(0xFFFFD54F.toInt()); setPadding(0, dp(8), 0, dp(8)) }
        val qPlay = Button(this).apply {
            text = "⏯  تشغيل / إيقاف مؤقت"
            setOnClickListener { player?.let { if (it.isPlaying) it.pause() else it.start() } }
        }
        quranLayer.addView(qTitle)
        quranLayer.addView(qList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        quranLayer.addView(qStatus); quranLayer.addView(qPlay)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            visibility = View.GONE
        }

        root.addView(homeLayer); root.addView(grid); root.addView(quranLayer); root.addView(web)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        buildTiles()
        loadTimings(false)
        handler.removeCallbacks(ticker); handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release(); adhanPlayer?.release()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent); showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            web.visibility == View.VISIBLE -> if (web.canGoBack()) web.goBack() else openQuranMenu()
            quranLayer.visibility == View.VISIBLE -> when (qLevel) {
                2 -> showReciters(); 1 -> openQuranMenu(); else -> showHome()
            }
            grid.visibility == View.VISIBLE -> showHome()
        }
    }

    private fun show(v: View) {
        listOf(homeLayer, grid, quranLayer, web).forEach { it.visibility = if (it === v) View.VISIBLE else View.GONE }
    }

    private fun showHome() { show(homeLayer); tilesRow.getChildAt(0)?.requestFocus() }

    private fun showAllApps() {
        grid.adapter = AppsAdapter(installedApps()); show(grid); grid.requestFocus()
    }

    // ===================== التطبيقات =====================
    private fun buildTiles() {
        tilesRow.removeAllViews()
        val pm = packageManager
        for (i in defaults.indices) {
            val pkg = prefs.getString("slot$i", defaults[i])!!
            val ok = pm.getLaunchIntentForPackage(pkg) != null || pm.getLeanbackLaunchIntentForPackage(pkg) != null
            if (ok) {
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                tilesRow.addView(makeTile(label, pm.getApplicationIcon(pkg), null, { launch(pkg) }, { pickApp(i) }))
            } else {
                tilesRow.addView(makeTile("+ اختر تطبيقاً", null, null, { pickApp(i) }, { pickApp(i) }))
            }
        }
        tilesRow.addView(makeTile("القرآن الكريم", null, "📖", { openQuranMenu() }, null))
        tilesRow.addView(makeTile("كل التطبيقات", getDrawable(android.R.drawable.ic_menu_agenda), null, { showAllApps() }, null))
        tilesRow.addView(makeTile("الإعدادات", getDrawable(android.R.drawable.ic_menu_preferences), null, {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, null))
        if (homeLayer.visibility == View.VISIBLE) tilesRow.getChildAt(0)?.requestFocus()
    }

    private fun makeTile(label: String, icon: Drawable?, emoji: String?, onClick: () -> Unit, onLong: (() -> Unit)?): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            isFocusable = true; isClickable = true
            background = tileBg()
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(120), dp(120)).apply { setMargins(dp(8), dp(12), dp(8), dp(12)) }
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }
        scaleOnFocus(tile)
        if (icon != null) tile.addView(ImageView(this).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(dp(56), dp(56)))
        else if (emoji != null) tile.addView(TextView(this).apply { text = emoji; textSize = 36f; gravity = Gravity.CENTER })
        tile.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 2
            setPadding(0, dp(4), 0, 0)
        })
        return tile
    }

    private fun installedApps(): List<ResolveInfo> {
        val pm = packageManager
        val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        val b = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return (a + b).distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
    }

    private fun pickApp(slot: Int) {
        val apps = installedApps()
        AlertDialog.Builder(this).setTitle("اختر التطبيق")
            .setItems(apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()) { _, w ->
                prefs.edit().putString("slot$slot", apps[w].activityInfo.packageName).apply(); buildTiles()
            }.show()
    }

    private fun launch(pkg: String) {
        val pm = packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else Toast.makeText(this, "التطبيق غير مثبت", Toast.LENGTH_SHORT).show()
    }

    inner class AppsAdapter(val apps: List<ResolveInfo>) : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int) = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, c: View?, parent: ViewGroup): View {
            val ri = apps[p]
            val box = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(8), dp(12), dp(8), dp(12))
            }
            box.addView(ImageView(this@MainActivity).apply { setImageDrawable(ri.loadIcon(packageManager)) },
                LinearLayout.LayoutParams(dp(64), dp(64)))
            box.addView(TextView(this@MainActivity).apply {
                text = ri.loadLabel(packageManager); textSize = 14f
                setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1
            })
            return box
        }
    }

    // ===================== مواقيت الصلاة =====================
    private fun buildPrayerBar() {
        prayerBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true; isClickable = true
            background = tileBg()
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener { askCity() }
        }
        scaleOnFocus(prayerBar)
        nextText = TextView(this).apply { textSize = 18f; setTextColor(0xFFFFD54F.toInt()); gravity = Gravity.CENTER }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((k, ar) in prayerNames) {
            val c = TextView(this).apply {
                text = "$ar\n--:--"; gravity = Gravity.CENTER; textSize = 16f
                setTextColor(Color.WHITE); setPadding(dp(14), dp(6), dp(14), dp(2))
            }
            prayerCells[k] = c; row.addView(c)
        }
        prayerBar.addView(nextText); prayerBar.addView(row)
    }

    private fun city() = prefs.getString("city", "Mecca")!!
    private fun country() = prefs.getString("country", "Saudi Arabia")!!

    private fun askCity() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), 0) }
        val c = EditText(this).apply { hint = "City (e.g. Casablanca)"; setText(city()); setSingleLine() }
        val k = EditText(this).apply { hint = "Country (e.g. Morocco)"; setText(country()); setSingleLine() }
        box.addView(c); box.addView(k)
        AlertDialog.Builder(this).setTitle("المدينة والدولة (بالإنجليزية)").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                prefs.edit().putString("city", c.text.toString().trim()).putString("country", k.text.toString().trim()).apply()
                loadTimings(true)
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun loadTimings(force: Boolean) {
        hint.text = "اضغط OK على المواقيت لتغيير المدينة (${city()}) • اضغط مطولاً على أي تطبيق لتغييره"
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val key = "$today|${city()}|${country()}"
        val cached = prefs.getString("pt", "") ?: ""
        if (!force && prefs.getString("pt_key", "") == key && cached.isNotEmpty()) {
            timings = cached.split(";").associate { val p = it.split("="); p[0] to p[1] }
            return
        }
        val url = "https://api.aladhan.com/v1/timingsByCity?city=${URLEncoder.encode(city(), "UTF-8")}" +
                "&country=${URLEncoder.encode(country(), "UTF-8")}"
        Thread {
            try {
                val j = JSONObject(httpGet(url)).getJSONObject("data").getJSONObject("timings")
                val m = prayerNames.keys.associateWith { j.getString(it).take(5) }
                prefs.edit().putString("pt", m.entries.joinToString(";") { "${it.key}=${it.value}" })
                    .putString("pt_key", key).apply()
                runOnUiThread { timings = m }
            } catch (e: Exception) {
                runOnUiThread { if (timings.isEmpty()) nextText.text = "تعذر تحميل المواقيت – تحقق من الإنترنت والمدينة" }
            }
        }.start()
    }

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun secOf(t: String): Int { val p = t.take(5).split(":"); return p[0].toInt() * 3600 + p[1].toInt() * 60 }

    private fun updatePrayerUi() {
        if (timings.isEmpty()) { if (nextText.text.isEmpty()) nextText.text = "جاري تحميل مواقيت الصلاة…"; return }
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 3600 + cal.get(Calendar.MINUTE) * 60 + cal.get(Calendar.SECOND)
        var next: String? = null; var nextSec = 0
        for (k in prayerNames.keys) {
            if (k == "Sunrise") continue
            val s = secOf(timings[k] ?: continue)
            if (s > now) { next = k; nextSec = s; break }
            val id = "$k${cal.get(Calendar.DAY_OF_YEAR)}"
            if (now - s in 0..59 && lastAdhan != id) { lastAdhan = id; onAdhan(k) }
        }
        if (next == null) { next = "Fajr"; nextSec = secOf(timings["Fajr"] ?: "00:00") + 86400 }
        val r = nextSec - now
        nextText.text = "الصلاة القادمة: ${prayerNames[next]}  بعد  %02d:%02d:%02d".format(r / 3600, (r % 3600) / 60, r % 60)
        for ((k, ar) in prayerNames) {
            prayerCells[k]?.apply {
                text = "$ar\n${timings[k] ?: "--:--"}"
                setTextColor(if (k == next) 0xFFFFD54F.toInt() else Color.WHITE)
            }
        }
    }

    private fun onAdhan(k: String) {
        Toast.makeText(this, "حان الآن وقت صلاة ${prayerNames[k]}", Toast.LENGTH_LONG).show()
        val id = resources.getIdentifier("adhan", "raw", packageName)
        if (id != 0) { adhanPlayer?.release(); adhanPlayer = MediaPlayer.create(this, id); adhanPlayer?.start() }
    }

    // ===================== القرآن الكريم =====================
    private fun setItems(items: List<String>) {
        qItems = items
        qList.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.textSize = 20f; v.setTextColor(Color.WHITE); return v
            }
        }
        qList.requestFocus()
    }

    private fun openQuranMenu() {
        qLevel = 0; qTitle.text = "القرآن الكريم"
        show(quranLayer)
        setItems(listOf("📖  قراءة المصحف (quran.com)", "🎧  الاستماع إلى القرآن (القرّاء)"))
    }

    private fun onQuranClick(pos: Int) {
        when (qLevel) {
            0 -> if (pos == 0) {
                if (web.url == null) web.loadUrl("https://quran.com/ar")
                show(web); web.requestFocus()
            } else showReciters()
            1 -> { curRec = recs[pos]; showSurahs() }
            2 -> play(pos)
        }
    }

    private fun showReciters() {
        qLevel = 1; qTitle.text = "اختر القارئ"
        show(quranLayer)
        if (recs.isNotEmpty()) { setItems(recs.map { it.name }); return }
        qStatus.text = "جاري التحميل…"
        Thread {
            try {
                val rj = JSONObject(httpGet("https://mp3quran.net/api/v3/reciters?language=ar")).getJSONArray("reciters")
                val list = ArrayList<Rec>()
                for (i in 0 until rj.length()) {
                    val r = rj.getJSONObject(i); val ms = r.getJSONArray("moshaf")
                    for (j in 0 until ms.length()) {
                        val m = ms.getJSONObject(j)
                        val sl = m.getString("surah_list").split(",").mapNotNull { it.trim().toIntOrNull() }
                        list.add(Rec("${r.getString("name")} – ${m.getString("name")}", m.getString("server"), sl))
                    }
                }
                val sj = JSONObject(httpGet("https://mp3quran.net/api/v3/suwar?language=ar")).getJSONArray("suwar")
                val names = HashMap<Int, String>()
                for (i in 0 until sj.length()) { val s = sj.getJSONObject(i); names[s.getInt("id")] = s.getString("name") }
                runOnUiThread { recs = list; suwar = names; qStatus.text = ""; if (qLevel == 1) setItems(recs.map { it.name }) }
            } catch (e: Exception) {
                runOnUiThread { qStatus.text = "تعذر التحميل – تحقق من الإنترنت" }
            }
        }.start()
    }

    private fun showSurahs() {
        val r = curRec ?: return
        qLevel = 2; qTitle.text = r.name
        setItems(r.surahs.map { "$it.  ${suwar[it] ?: "سورة $it"}" })
    }

    private fun play(index: Int) {
        val r = curRec ?: return
        curIndex = index
        val n = r.surahs[index]
        val base = if (r.server.endsWith("/")) r.server else r.server + "/"
        val url = base + "%03d.mp3".format(n)
        qStatus.text = "جاري التشغيل: ${suwar[n] ?: n}…"
        player?.release()
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
            setDataSource(url)
            setOnPreparedListener { it.start(); qStatus.text = "▶  ${suwar[n] ?: n} — ${r.name}" }
            setOnCompletionListener { if (curIndex + 1 < r.surahs.size) play(curIndex + 1) }
            setOnErrorListener { _, _, _ -> qStatus.text = "تعذر تشغيل هذه السورة"; true }
            prepareAsync()
        }
    }
}
